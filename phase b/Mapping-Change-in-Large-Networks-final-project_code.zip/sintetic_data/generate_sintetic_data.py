import random
import json
from pathlib import Path

# Configuration
NUM_PAPERS = 3000
YEARS = list(range(2000, 2011))

FIELDS = {
    "A": "Artificial Intelligence",
    "B": "Computer Vision",
    "C": "Natural Language Processing",
    "D": "Data Mining",
    "E": "Robotics",
    "F": "Machine Learning",
    "G": "Cybersecurity",
    "H": "Bioinformatics",
    "I": "Theoretical CS",
    "J": "Quantum Computing",
    "K": "Distributed Systems"
}

# Cluster logic: tracks which clusters to grow or decay
CLUSTER_PLAN = {
    2000: ["A", "B"],                    # 2 clusters
    2001: ["A", "B", "C"],               # new C citing A heavily
    2002: ["A", "B", "C", "D", "E"],     # add D, E
    2003: ["A", "B", "C", "D", "E", "F"],# add F
    2004: ["A", "B", "C", "D", "E", "F", "G"],
    2005: ["A", "B", "C", "D", "E", "F", "G", "H"], # H cites B+C
    2006: ["A", "B", "C", "D", "E", "F", "G", "H", "I"], # new I
    2007: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"],
    2008: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"],
    2009: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"],
    2010: ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K"]
}

DECAY_CLUSTER = "B"  # won't get new papers after 2000

# Output file
OUTPUT_PATH = Path("synthetic_3000_2000_2010.jsonl")
OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)

def generate_paper_id(index):
    return f"P{index:05d}"

# State
all_papers = []
papers_by_year = {y: [] for y in YEARS}

paper_index = 0

for year in YEARS:
    clusters = CLUSTER_PLAN[year]
    for cluster in clusters:
        # Skip adding new papers to DECAY_CLUSTER from 2001 onwards
        if cluster == DECAY_CLUSTER and year > 2000:
            continue

        num_papers = random.randint(60, 100)
        for _ in range(num_papers):
            pid = generate_paper_id(paper_index)
            paper_index += 1
            fos_name = FIELDS[cluster]

            # References: only earlier papers
            eligible_refs = [p["id"] for y in YEARS if y < year for p in papers_by_year[y]]
            num_refs = random.randint(0, 5) if eligible_refs else 0
            references = random.sample(eligible_refs, k=min(num_refs, len(eligible_refs)))

            # Special: for cluster C (2001), make it cite A heavily
            if cluster == "C" and year == 2001:
                refs_from_A = [p["id"] for p in papers_by_year[2000] if p["fos"][0]["name"] == FIELDS["A"]]
                references += random.sample(refs_from_A, k=min(5, len(refs_from_A)))

            # Special: for cluster H (2005), make it cite B and C
            if cluster == "H" and year == 2005:
                refs_from_BC = [p["id"] for p in papers_by_year[2004] if p["fos"][0]["name"] in [FIELDS["B"], FIELDS["C"]]]
                references += random.sample(refs_from_BC, k=min(5, len(refs_from_BC)))

            paper = {
                "id": pid,
                "title": f"Synthetic Paper {pid}",
                "year": year,
                "authors": [{"name": f"Author {random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ')}", "id": random.randint(1000, 9999)}],
                "references": references,
                "fos": [{"name": fos_name, "w": round(random.uniform(0.6, 1.0), 4)}]
            }

            all_papers.append(paper)
            papers_by_year[year].append(paper)

# Save
with open(OUTPUT_PATH, "w", encoding="utf-8") as f:
    for paper in all_papers:
        json.dump(paper, f)
        f.write("\n")

OUTPUT_PATH, len(all_papers)
