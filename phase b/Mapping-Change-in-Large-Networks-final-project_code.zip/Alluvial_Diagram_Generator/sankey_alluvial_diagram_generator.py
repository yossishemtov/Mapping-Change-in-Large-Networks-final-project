import os
import json
import re
import webbrowser

def generate_single_html_sankey(flow, results_dir="results"):
    cleaned_flow = {k: v for k, v in flow.items() if v > 0}
    os.makedirs(results_dir, exist_ok=True)
    existing = [f for f in os.listdir(results_dir) if re.match(r"sankey_diagram_\d+\.html", f)]
    indices = [int(re.search(r"_(\d+)\.html", f).group(1)) for f in existing]
    next_index = max(indices) + 1 if indices else 1
    output_path = os.path.join(results_dir, f"sankey_diagram_{next_index}.html")

    node_set = set()
    for src, tgt in cleaned_flow:
        node_set.add(src)
        node_set.add(tgt)

    nodes = []
    for name in node_set:
        year, cluster = name.split("_", 1)
        nodes.append({
            "name": name,
            "year": int(year),
            "cluster": cluster
        })

    links = []
    for (src, tgt), value in cleaned_flow.items():
        links.append({
            "source": src,
            "target": tgt,
            "value": value
        })

    nodes_js = json.dumps(nodes, indent=2)
    links_js = json.dumps(links, indent=2)

    html_code = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Sankey Diagram</title>
  <script src="https://d3js.org/d3.v7.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/d3-sankey@0.12.3/dist/d3-sankey.min.js"></script>
  <style>
    .node rect {{ cursor: move; fill-opacity: .9; shape-rendering: crispEdges; }}
    .node text {{ pointer-events: none; font: 10px sans-serif; }}
    .link {{ fill: none; stroke-opacity: .7; }}
    .link:hover {{ stroke-opacity: .6; }}
    .tooltip {{
      position: absolute;
      text-align: left;
      padding: 6px;
      font: 12px sans-serif;
      background: white;
      border: 1px solid #aaa;
      pointer-events: none;
    }}
  </style>
</head>
<body>
<svg width="1400" height="750"></svg>
<div id="tooltip" class="tooltip" style="opacity:0;"></div>

<script>
const graph = {{
  "nodes": {nodes_js},
  "links": {links_js}
}};

const svg = d3.select("svg"),
      width = +svg.attr("width"),
      height = +svg.attr("height");

const marginTop = 30;
const g = svg.append("g")
  .attr("transform", `translate(0,${{marginTop}})`);

const sankey = d3.sankey()
  .nodeId(d => d.name)
  .nodeWidth(0)
  .nodePadding(10)
  .extent([[1, 1], [width - 100, height - marginTop - 6]]);

const minYear = d3.min(graph.nodes, d => d.year);
const maxYear = d3.max(graph.nodes, d => d.year);
const xScale = d3.scaleLinear().domain([minYear, maxYear]).range([50, width - 250]);

sankey(graph);

graph.nodes.forEach(d => {{
  d.x0 = xScale(d.year);
  d.x1 = d.x0;
}});

const clusterColors = {{}};
const color = d3.scaleOrdinal(d3.schemeTableau10);
graph.nodes.forEach(d => {{
  if (!(d.cluster in clusterColors)) {{
    clusterColors[d.cluster] = color(d.cluster);
  }}
}});

const tooltip = d3.select("#tooltip");

g.append("g")
  .selectAll("path")
  .data(graph.links)
  .join("path")
  .attr("class", "link")
  .attr("d", d3.sankeyLinkHorizontal())
  .attr("stroke-width", d => Math.max(1, d.width))
  .attr("stroke", d => clusterColors[d.source.cluster])
  .on("mouseover", function(event, d) {{
    tooltip.style("opacity", 1)
      .html(`<b>${{d.source.name}} → ${{d.target.name}}:</b> ${{d.value}}<br/>From: ${{d.source.cluster}}<br/>To: ${{d.target.cluster}}`)
      .style("left", (event.pageX + 10) + "px")
      .style("top", (event.pageY - 28) + "px");
  }})
  .on("mouseout", () => tooltip.style("opacity", 0));

// Creating nodes (rectangles) – invisible because width=0, but they preserve space
const node = g.append("g")
  .selectAll("g")
  .data(graph.nodes)
  .join("g")
  .attr("class", "node")
  .attr("transform", d => `translate(${{d.x0}},${{d.y0}})`);

node.append("rect")
  .attr("height", d => d.y1 - d.y0)
  .attr("width", 0)
  .attr("fill", d => clusterColors[d.cluster]);

// Vertical lines and year labels
const years = Array.from(new Set(graph.nodes.map(d => d.year))).sort((a, b) => a - b);
const yearGroup = g.append("g").attr("class", "years");

years.forEach(year => {{
  const x = xScale(year);
  yearGroup.append("text")
    .attr("x", x)
    .attr("y", -10)
    .attr("text-anchor", "middle")
    .attr("font-size", "12px")
    .attr("fill", "gray")
    .text(year);

  yearGroup.append("line")
    .attr("x1", x)
    .attr("x2", x)
    .attr("y1", 0)
    .attr("y2", height)
    .attr("stroke", "gray")
    .attr("stroke-width", 1)
    .attr("stroke-dasharray", "4 4")
    .attr("stroke-opacity", 0.4);
}});

// 🧠 Legend ordering by final node Y position (even for dying clusters)
const nodesByCluster = d3.group(graph.nodes, d => d.cluster);
const clusterYOrder = Array.from(nodesByCluster.entries())
  .map(([cluster, nodes]) => {{
    const lastYear = d3.max(nodes, d => d.year);
    const lastNode = nodes.find(d => d.year === lastYear);
    return {{ cluster, y: lastNode.y0 }};
  }})
  .sort((a, b) => a.y - b.y);
const clusterList = clusterYOrder.map(d => d.cluster);

// 🎨 Sorted Legend
const legend = svg.append("g")
  .attr("transform", `translate(${{width - 200}}, 100)`);

legend.selectAll("g")
  .data(clusterList)
  .join("g")
  .attr("transform", (d, i) => `translate(0, ${{i * 20}})`)
  .each(function(d) {{
    const g = d3.select(this);
    g.append("rect")
      .attr("width", 25)
      .attr("height", 10)
      .attr("fill", clusterColors[d])
      .attr("fill-opacity", 0.7);
    g.append("text")
      .attr("x", 40)
      .attr("y", 15)
      .attr("font-size", "14px")
      .attr("font-weight", "bold")
      .attr("fill", clusterColors[d])
      .text(d);
  }});
</script>
</body>
</html>
"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_code)

    webbrowser.open(f"file://{os.path.abspath(output_path)}")
    print(f"✅ Sankey diagram saved to: {output_path}")
    return output_path

__all__ = ["generate_single_html_sankey"]
