import plotly.graph_objects as go
from collections import defaultdict
import hashlib
import os


def create_alluvial_flow_from_scores_and_transactions(cluster_scores_per_year, transactions_per_year):
    flow = {}
    years = sorted(cluster_scores_per_year.keys())

    for i in range(len(years) - 1):
        year_a = years[i]
        year_b = years[i + 1]

        prev_scores = cluster_scores_per_year[year_a]
        curr_scores = cluster_scores_per_year[year_b]

        # 1. Transaction-based flows – show which cluster transferred to which
        for src, tgt, amount in transactions_per_year.get(year_b, []):
            src_key = f"{year_a}_{src}"
            tgt_key = f"{year_b}_{tgt}"
            flow[(src_key, tgt_key)] = amount

        # 2. Continuity of the same cluster (if it exists in both years)
        for cname in set(prev_scores) & set(curr_scores):
            src_key = f"{year_a}_{cname}"
            tgt_key = f"{year_b}_{cname}"
            flow[(src_key, tgt_key)] = curr_scores[cname]

    return flow

def get_unique_filename(base_dir, base_name="alluvial_diagram", ext=".html"):
    i = 1
    while True:
        filename = f"{base_name}_{i}{ext}"
        full_path = os.path.join(base_dir, filename)
        if not os.path.exists(full_path):
            return full_path
        i += 1


def cluster_color(name):
    digest = hashlib.md5(name.encode()).hexdigest()
    r, g, b = int(digest[0:2], 16), int(digest[2:4], 16), int(digest[4:6], 16)
    return f'rgb({r},{g},{b})'

def plot_custom_alluvial(flow, cluster_names=None, include_clusters=None):
    if include_clusters:
        include_clusters = set(include_clusters)
        flow = {
            (src, tgt): val
            for (src, tgt), val in flow.items()
            if src.split('_')[1] in include_clusters or tgt.split('_')[1] in include_clusters
        }

    labels = set()
    label_to_year = {}
    label_to_cluster = {}
    cluster_first_year = {}
    cluster_last_label = {}

    for src, tgt in flow:
        labels.update([src, tgt])
        for label in (src, tgt):
            year, cluster = label.split('_')
            year = int(year)
            label_to_year[label] = year
            label_to_cluster[label] = cluster
            if cluster not in cluster_first_year or year < cluster_first_year[cluster]:
                cluster_first_year[cluster] = year
            if cluster not in cluster_last_label or year > int(cluster_last_label[cluster].split('_')[0]):
                cluster_last_label[cluster] = label

    years = sorted(set(label_to_year.values()))
    year_to_index = {year: idx for idx, year in enumerate(years)}
    sorted_labels = sorted(labels, key=lambda x: (label_to_year[x], x.split('_')[1]))

    unique_clusters = sorted(set(label_to_cluster.values()), key=lambda c: cluster_first_year[c])

    main_flows_by_cluster = defaultdict(list)
    for (src, tgt), value in flow.items():
        src_year, src_cluster = src.split('_')
        tgt_year, tgt_cluster = tgt.split('_')
        if tgt_cluster == src_cluster and int(tgt_year) == int(src_year) + 1:
            main_flows_by_cluster[src_cluster].append(value)

    max_score_by_cluster = {cluster: max(scores) for cluster, scores in main_flows_by_cluster.items()}
    total_max_score = sum(max_score_by_cluster.values())

    # 🟣 Apply minimal height logic
    min_rel_height = 0.02  # 2% of total vertical space
    cluster_heights = {}
    total_available = 1.0
    total_min_height = min_rel_height * len(unique_clusters)
    total_variable_height = max(total_available - total_min_height, 0)

    norm_factor = total_variable_height / total_max_score if total_max_score > 0 else 0
    for cluster in unique_clusters:
        raw_score = max_score_by_cluster.get(cluster, 0)
        rel_height = min_rel_height + raw_score * norm_factor
        cluster_heights[cluster] = rel_height

    cluster_to_yrange = {}
    y_pointer = 0
    for cluster in unique_clusters:
        h = cluster_heights[cluster]
        cluster_to_yrange[cluster] = (y_pointer, y_pointer + h)
        y_pointer += h

    nodes = {}
    block_width = 0.0
    block_height = 0.0
    for label in sorted_labels:
        year = label_to_year[label]
        cluster = label_to_cluster[label]
        x = year_to_index[year] / (len(years) - 1)
        y0_strip, y1_strip = cluster_to_yrange.get(cluster, (0, 0))
        y_center = (y0_strip + y1_strip) / 2
        y = y_center - block_height / 2
        nodes[label] = (x, y, block_width, block_height)

    fig = go.Figure()
    colors_by_cluster = {cl: cluster_color(cl) for cl in unique_clusters}

    for label, (x, y, w, h) in nodes.items():
        fig.add_shape(type="rect", x0=x, x1=x + w, y0=y, y1=y + h,
                      fillcolor='rgba(0,0,0,0)', line=dict(width=0, color='rgba(0,0,0,0)'))

    min_thickness_px = 2.0
    total_height_px = 1000

    primary_flows = []
    secondary_flows = []

    for (src, tgt), value in sorted(flow.items(), key=lambda kv: kv[1]):
        if value <= 0:
            continue
        if label_to_cluster[src] == label_to_cluster[tgt]:
            primary_flows.append((src, tgt, value))
        else:
            secondary_flows.append((src, tgt, value))

    def draw_flow(src, tgt, value, opacity):
        x0, y0, w0, h0 = nodes[src]
        x1, y1, w1, h1 = nodes[tgt]
        src_center = y0
        tgt_center = y1
        cluster_src = label_to_cluster[src]
        cluster_tgt = label_to_cluster[tgt]
        color = colors_by_cluster[cluster_src]

        cluster_max = max_score_by_cluster.get(cluster_src, 1)
        normalized = value / cluster_max if cluster_max > 0 else 0

        y0_strip, y1_strip = cluster_to_yrange.get(cluster_src, (0, 0))
        rel_strip_height = y1_strip - y0_strip
        usable_strip_height = rel_strip_height * 0.8

        is_primary = cluster_src == cluster_tgt

        # ✅ Apply min thickness only to secondary flows
        if not is_primary:
            thickness = max(min_thickness_px, normalized * usable_strip_height * total_height_px)
        else:
            thickness = normalized * usable_strip_height * total_height_px

        x_ctrl1 = x0 + (x1 - x0) * 0.48
        x_ctrl2 = x0 + (x1 - x0) * 0.52

        ctrl_y1 = src_center + 0.01
        ctrl_y2 = tgt_center - 0.01

        path = f"M {x0},{src_center} C {x_ctrl1},{ctrl_y1} {x_ctrl2},{ctrl_y2} {x1},{tgt_center}"

        fig.add_shape(type="path", path=path,
                      line=dict(color=color, width=thickness),
                      opacity=opacity)

        if is_primary:
            fig.add_trace(go.Scatter(
                x=[x0, x_ctrl1, x_ctrl2, x1],
                y=[src_center, ctrl_y1, ctrl_y2, tgt_center],
                mode="lines",
                line=dict(width=thickness + 2, color='rgba(0,0,0,0)'),
                hoverinfo="text",
                text=[f"{src} → {tgt} : {value:.2f}"] * 4,
                showlegend=False
            ))

    for src, tgt, value in primary_flows:
        draw_flow(src, tgt, value, opacity=0.7)

    for src, tgt, value in secondary_flows:
        draw_flow(src, tgt, value, opacity=1)

    for idx, year in enumerate(years):
        x_pos = idx / (len(years) - 1)
        fig.add_shape(type="line", x0=x_pos, x1=x_pos, y0=0, y1=1,
                      line=dict(color="gray", width=1, dash="dot"),
                      xref="x", yref="paper")
        fig.add_annotation(x=x_pos, y=1.02, text=str(year), showarrow=False,
                           xref="x", yref="paper", font=dict(size=12))

    for cluster in unique_clusters:
        y0, y1 = cluster_to_yrange[cluster]
        y_center = (y0 + y1) / 2
        fig.add_annotation(
            x=1.02,
            y=y_center,
            xref="paper",
            yref="paper",
            text=cluster_names.get(cluster, cluster) if cluster_names else cluster,
            showarrow=False,
            font=dict(size=14, color=colors_by_cluster[cluster]),
            align="left",
            bgcolor="white",
            borderpad=2
        )

    start_year = years[0]
    end_year = years[-1]
    fig.update_layout(
        title_text=f"Alluvial Diagram: Mapping change in citation networks ({start_year}–{end_year})",
        xaxis=dict(range=[-0.02, 1.02], showgrid=False, zeroline=False, visible=False),
        yaxis=dict(range=[0, 1], showgrid=False, zeroline=False, visible=False),
        plot_bgcolor='white',
        height=total_height_px
    )

    fig.show()

    # Save to results/
    results_dir = os.path.join(os.path.dirname(__file__), "..", "results")
    os.makedirs(results_dir, exist_ok=True)
    output_path = get_unique_filename(results_dir)
    fig.write_html(output_path)
    print(f"📁 Alluvial diagram saved to {output_path}")


__all__ = ["create_alluvial_flow_from_scores_and_transactions",  "plot_custom_alluvial" ]
