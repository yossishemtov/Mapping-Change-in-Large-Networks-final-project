
import json
import torch
from collections import defaultdict, Counter


def create_initial_embeddings(papers, fos_dim=32):
    """
    Creates one-hot or weighted embedding vectors for each paper based on its Field of Study (FOS).
    Assumes each paper has a single FOS (uses only the first if multiple are present).
    Embedding size = fos_dim.

    Args:
        papers (list): List of paper dictionaries, each with a "fos" field.
        fos_dim (int): Dimension of the embedding (i.e., number of FOS categories to consider).

    Returns:
        embeddings (torch.Tensor): A [num_papers x fos_dim] tensor with one-hot or weighted FOS vectors.
        fos_to_idx (dict): Mapping from FOS name to index in the embedding vector.
        paper_id_to_index (dict): Mapping from paper ID to its row index in the embedding matrix.
    """
    # Collect all unique FOS names (sorted) and truncate to fos_dim
    all_fos_names = sorted({fos["name"] for paper in papers for fos in paper.get("fos", [])})
    if len(all_fos_names) > fos_dim:
        print(f"⚠️ Warning: {len(all_fos_names)} FOS entries found. Truncating to {fos_dim}.")
    selected_fos = all_fos_names[:fos_dim]
    fos_to_idx = {fos: i for i, fos in enumerate(selected_fos)}

    embeddings = torch.zeros((len(papers), fos_dim))
    paper_id_to_index = {}

    for i, paper in enumerate(papers):
        paper_id_to_index[paper["id"]] = i
        for fos in paper.get("fos", []):
            fos_name = fos["name"]
            weight = fos.get("w", 1.0)
            if fos_name in fos_to_idx:
                embeddings[i, fos_to_idx[fos_name]] = weight
                break  # Only one FOS per paper is used

    print(f"🔧 Created {len(papers)} initial embeddings of dimension {fos_dim}")
    return embeddings, fos_to_idx, paper_id_to_index

def load_papers(jsonl_path):
    papers = []
    with open(jsonl_path, 'r', encoding='utf-8') as f:
        for line in f:
            papers.append(json.loads(line))
    return papers

def update_cluster_scores(previous_assignment, current_assignment, current_papers,
                           cluster_scores, cluster_penalties,
                          year, citing_precent=10, cited_ratio=0.1):
    transactions = []

    # Merge all known cluster assignments (previous + current)
    merged_assignment = {**previous_assignment, **current_assignment}

    # Step 0: Add initial score based on the number of new papers added to each cluster
    new_cluster_counts = Counter(current_assignment.values())
    for cname, count in new_cluster_counts.items():
        previous_score = cluster_scores.get(cname, 0)
        is_new = cname not in cluster_scores

        # Update raw score
        cluster_scores[cname] = previous_score + count

        if not is_new:
            # Addition ratio out of total score
            added_ratio = count / cluster_scores[cname] if cluster_scores[cname] > 0 else 0
            if added_ratio < 0.1:
                if cname not in cluster_penalties:
                    penalty = 0.1 * cluster_scores[cname]
                    cluster_penalties[cname] = penalty
                    cluster_scores[cname] -= penalty
            else:
                if cname in cluster_penalties:
                    del cluster_penalties[cname]

    # Step 0.5: Penalize old clusters that received no new papers
    previous_clusters = set(previous_assignment.values())
    for cname in previous_clusters:
        if cname not in new_cluster_counts:
            base_score = cluster_scores.get(cname, 0)
            if base_score <= 5:
                # Do not penalize clusters with score below 5
                if cname in cluster_penalties:
                    del cluster_penalties[cname]
                continue

            if cname not in cluster_penalties:
                penalty = 0.1 * base_score
                cluster_penalties[cname] = penalty
                cluster_scores[cname] -= penalty
            else:
                cluster_scores[cname] -= cluster_penalties[cname]

    # Step 1: Classify citations by clusters
    id_to_cluster = current_assignment  # Map from paper ID to its cluster in the current year
    citations = {p["id"]: p.get("references", []) for p in current_papers}

    cluster_citations = defaultdict(Counter)

    for pid, refs in citations.items():
        citing_cluster = id_to_cluster.get(pid)
        if not citing_cluster:
            continue
        for ref in refs:
            cited_cluster = merged_assignment.get(ref)
            if cited_cluster:
                cluster_citations[citing_cluster][cited_cluster] += 1

    # Debugging output – Citation analysis
    for from_cluster, counter in cluster_citations.items():
        total = sum(counter.values())
        print(f"\n📊 Cluster '{from_cluster}' citation analysis in year {year}:")
        for to_cluster, count in counter.items():
            percent = (count / total) * 100 if total > 0 else 0
            print(f"  → Cited '{to_cluster}': {count} times ({percent:.1f}%)")

            # Apply transaction only if cross-cluster citing is significant
            if from_cluster != to_cluster and percent >= citing_precent:
                cited_score = cluster_scores.get(to_cluster, 0)
                if cited_score <= 0:
                    continue  # Cluster has disappeared or is already weak

                if count >= cited_ratio * cited_score:
                    transfer_amount = 0.5 * count
                    if transfer_amount <= cited_score:
                        # Perform the transaction
                        cluster_scores[to_cluster] -= transfer_amount
                        cluster_scores[from_cluster] += transfer_amount
                        transactions.append((to_cluster, from_cluster, transfer_amount))
                    else: # the cited cluster dont have enough score to give he will default give half of what he have
                        cluster_scores[to_cluster] = cited_score*0.5
                        cluster_scores[from_cluster] += cited_score*0.5
                        transactions.append((to_cluster, from_cluster, cited_score*0.5))



    return cluster_scores, cluster_penalties, transactions





