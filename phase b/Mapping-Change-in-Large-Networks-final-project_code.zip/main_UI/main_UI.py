import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import os
import sys


def run_ui():
    config = {
        "citing_precent": 30,
        "cited_ratio": 0.01,
        "enable_data_processing": False,
        "use_filter_data_phase": False,
        "categories_scientific_cs": [
            "Computer Science", "Artificial Intelligence", "Machine Learning", "Data Science",
            "Mathematics", "Physics", "Computational Science", "Robotics"
        ],
        "input_path": "data_set_Processing\\data.txt",
        "start_year_filter": 2000,
        "end_year_filter": 2020,
        "use_sankey_plot": True,
        "use_plotly": False
    }

    def load_resized_image(path, size):
        img = Image.open(path)
        img.thumbnail(size, Image.Resampling.LANCZOS)
        return ImageTk.PhotoImage(img)

    def create_tooltip(widget, text):
        tooltip = tk.Toplevel(widget)
        tooltip.wm_overrideredirect(True)
        tooltip.withdraw()

        label = tk.Label(
            tooltip,
            text=text,
            background="#f0faff",
            foreground="#000000",
            relief="solid",
            borderwidth=1,
            highlightbackground="#90a4ae",
            highlightthickness=1,
            font=("Segoe UI", 10),
            justify="left",
            anchor="w",
            wraplength=400
        )
        label.pack(ipadx=8, ipady=6)

        def enter(event):
            x = widget.winfo_rootx() + 20
            y = widget.winfo_rooty() + 20
            tooltip.wm_geometry(f"+{x}+{y}")
            tooltip.deiconify()

        def leave(event):
            tooltip.withdraw()

        widget.bind("<Enter>", enter)
        widget.bind("<Leave>", leave)

    def on_close():
        print("❌ User closed the configuration window.")
        root.destroy()
        sys.exit(0)

    def on_submit():
        errors = []

        # ----- Check citing_precent -----
        citing_text = citing_precent_var.get().strip()
        if not citing_text:
            errors.append("• 'Citing Percent' cannot be empty.")
        else:
            try:
                citing = int(citing_text)
                if not (0 <= citing <= 100):
                    errors.append("• 'Citing Percent' must be between 0 and 100.")
                else:
                    config["citing_precent"] = citing
            except:
                errors.append("• 'Citing Percent' must be an integer.")

        # ----- Check cited_ratio -----
        cited_text = cited_ratio_var.get().strip()
        if not cited_text:
            errors.append("• 'Cited Ratio' cannot be empty.")
        else:
            try:
                cited = float(cited_text)
                if not (0 <= cited <= 1):
                    errors.append("• 'Cited Ratio' must be between 0 and 1.")
                else:
                    config["cited_ratio"] = cited
            except:
                errors.append("• 'Cited Ratio' must be a number between 0 and 1.")

        # ----- Check at least one diagram type is selected -----
        if not (use_r_var.get() or use_plotly_var.get()):
            errors.append("• You must select at least one diagram type (Sankey or Plotly).")

        # ----- NLP and Filter checks -----
        nlp_enabled = enable_var.get()
        filter_enabled = filter_var.get()

        # Validation 1: NLP is off → check if processed file exists
        if not nlp_enabled:
            processed_path = "data_set_Processing/data_processed.jsonl"
            if not os.path.exists(processed_path):
                messagebox.showwarning(
                    "Missing Preprocessed Data",
                    f"The required preprocessed data file was not found:\n{processed_path}\n\n"
                    "NLP phase will now be enabled to allow full preprocessing."
                )
                enable_var.set(True)
                filter_var.set(True)
                toggle_fields()
                return  # stop and no run

        # Validation 2: NLP is on, Filter is off → check if filtered file exists
        if nlp_enabled and not filter_enabled:
            filtered_path = "data_set_Processing/filtered_data.jsonl"
            if not os.path.exists(filtered_path):
                messagebox.showwarning(
                    "Missing Filtered Data",
                    f"The file 'filtered_data.jsonl' was not found at:\n{filtered_path}\n\n"
                    "Filter phase will now be enabled to continue."
                )
                filter_var.set(True)
                toggle_fields()
                return  # stop and no run

        # Validation 3: NLP+Filter → check input path is valid
        if nlp_enabled:
            categories_val = categories_text.get("1.0", "end").strip()
            if not categories_val:
                errors.append("• 'Scientific Categories' cannot be empty when NLP is enabled.")
            else:
                config["categories_scientific_cs"] = [s.strip() for s in categories_val.split(",") if s.strip()]

            if filter_enabled:
                input_path = input_path_var.get().strip()
                start_year = start_year_var.get().strip()
                end_year = end_year_var.get().strip()

                if not input_path:
                    errors.append("• Input path cannot be empty when filter is enabled.")
                elif not os.path.exists(input_path):
                    errors.append(f"• Input file does not exist:\n  {input_path}")
                else:
                    config["input_path"] = input_path

                if not start_year.isdigit():
                    errors.append("• Start year must be a number.")
                else:
                    config["start_year_filter"] = int(start_year)

                if not end_year.isdigit():
                    errors.append("• End year must be a number.")
                else:
                    config["end_year_filter"] = int(end_year)

            config["enable_data_processing"] = True
            config["use_filter_data_phase"] = filter_enabled
        else:
            config["enable_data_processing"] = False
            config["categories_scientific_cs"] = []

        config["use_sankey_plot"] = use_r_var.get()
        config["use_plotly"] = use_plotly_var.get()

        # Show errors only if needed
        if errors:
            messagebox.showerror("Validation Failed", "\n".join(errors))
            return  # return to ui

        if nlp_enabled:
            proceed = messagebox.askokcancel(
                "Warning: Long Preprocessing Step",
                "You have enabled the NLP model processing phase.\n\n"
                "⚠️ This step performs a one-time heavy preprocessing that may take several hours to complete "
                "depending on the dataset size.\n\n"
                "For datasets with ~1.5 million papers, it can take 7–9 hours or longer.\n\n"
                "Are you sure you want to proceed?"
            )
            if not proceed:
                return  # User chose to cancel

        root.destroy()

    def toggle_fields():
        state = "normal" if enable_var.get() else "disabled"
        filter_state = "normal" if (enable_var.get() and filter_var.get() ) else "disabled"
        categories_text.config(state=state)
        filter_check.config(state=state)
        input_entry.config(state=filter_state)
        start_year_entry.config(state=filter_state)
        end_year_entry.config(state=filter_state)

        if enable_var.get() and config["categories_scientific_cs"]:
            categories_text.delete("1.0", "end")
            categories_text.insert("1.0", ", ".join(config["categories_scientific_cs"]))

    def on_nlp_toggle():
        if enable_var.get():
            filter_var.set(True)  # NLP enabled → force filter
        else:
            filter_var.set(False)  # NLP disabled → also disable filter
        toggle_fields()

    root = tk.Tk()
    root.title("Run Configuration")
    root.geometry("1300x700")
    root.configure(bg="#e0f7fa")

    # This path needs to be correct for the info icon to display.
    # Assuming 'info_icon.png' is in the same directory as the script.
    script_dir = os.path.dirname(os.path.abspath(__file__))
    info_icon_path = os.path.join(script_dir, "info_icon.png")
    # You also need sankey_alluvial_diagram.png and plotly_alluvial_diagram.png
    # in the same directory for the previews to work.
    sankey_diagram_path = os.path.join(script_dir, "sankey_alluvial_diagram.png")
    plotly_diagram_path = os.path.join(script_dir, "plotly_alluvial_diagram.png")

    # Check if the info icon exists
    if os.path.exists(info_icon_path):
        info_img = ImageTk.PhotoImage(Image.open(info_icon_path).resize((16, 16)))
    else:
        print(f"Warning: info_icon.png not found at {info_icon_path}. Tooltips will not have an icon.")
        info_img = None # Set to None or a default small image if you have one

    title_style = {"font": ("Segoe UI", 14, "bold"), "fg": "#1a237e", "bg": "#e0f7fa"}
    label_style = {"font": ("Segoe UI", 10), "bg": "#e0f7fa", "fg": "#37474f"}

    main_frame = tk.Frame(root, bg="#e0f7fa")
    main_frame.pack(fill="both", expand=True)

    left_frame = tk.Frame(main_frame, bg="#e0f7fa")
    left_frame.pack(side="left", padx=20, pady=20, anchor="n")

    right_frame = tk.Frame(main_frame, bg="#e0f7fa")
    right_frame.pack(side="right", padx=20, pady=20, anchor="n")

    left_frame.grid_columnconfigure(0, weight=0)
    left_frame.grid_columnconfigure(1, weight=0)
    left_frame.grid_columnconfigure(2, weight=0)

    row_current = 0

    # One-time Processing Phase Frame - Title is now on the border
    one_time_processing_frame = tk.LabelFrame(left_frame, text="One-time Processing Phase",
                                              font=("Segoe UI", 12, "bold"),
                                              fg="#1a237e", bg="#e0f7fa", bd=2, relief="groove", padx=10, pady=10)
    one_time_processing_frame.grid(row=row_current, column=0, columnspan=3, sticky="ew", pady=(0, 20))
    one_time_processing_frame.grid_columnconfigure(0, weight=0)
    one_time_processing_frame.grid_columnconfigure(1, weight=0)
    one_time_processing_frame.grid_columnconfigure(2, weight=0)

    inner_row_current = 0

    # Removed the separate title_and_info_frame as the LabelFrame text handles the title.
    # The comprehensive tooltip for the overall phase can be re-added to another element if desired,
    # but for now, it's removed to ensure the title is on the border.

    enable_frame = tk.Frame(one_time_processing_frame, bg="#e0f7fa")
    enable_frame.grid(row=inner_row_current, column=0, columnspan=2, sticky="w", pady=0, padx=0)

    enable_var = tk.BooleanVar(value=config["enable_data_processing"])
    enable_check = tk.Checkbutton(enable_frame, text="Enable NLP model Data Processing Phase", variable=enable_var,
                                  command=on_nlp_toggle, bg="#e0f7fa")
    enable_check.pack(side="left", padx=0, pady=0)
    if info_img: # Only add if the icon exists
        info_enable = tk.Label(enable_frame, image=info_img, bg="#e0f7fa", cursor="question_arrow")
        info_enable.pack(side="left", padx=0, pady=0)
        create_tooltip(info_enable, "Activate this to perform the one-time data preprocessing step."
                                    "\n\nThis phase performs a one-time preprocessing of the raw dataset in preparation for clustering and analysis. "
                                    "It is designed to run only once per dataset and may take several hours to complete, depending on the dataset size. "
                                    "\n\n"
                                    "In this phase:\n"
                                    "- The dataset is filtered by publication year, according to the user's configuration.\n"
                                    "- Articles without any citations or without FOS (Fields of Study) information are removed.\n"
                                    "- In the second part of this phase, for each article, all associated FOS terms are merged and mapped to higher-level scientific categories provided by the user.\n"
                                    "- This mapping is done using a pre-trained NLP model, which determines the best-matching macro-category for each article based on its FOS tags.\n\n"
                                    "This preprocessing is essential to reduce noise and ensure that the clustering and analysis are based only on meaningful, structured data.")

    inner_row_current += 1
    categories_label_frame = tk.Frame(one_time_processing_frame, bg="#e0f7fa")
    categories_label_frame.grid(row=inner_row_current, column=0, columnspan=3, sticky="w", pady=(10, 2), padx=0)
    tk.Label(categories_label_frame, text="Scientific Categories (comma-separated):", **label_style).pack(side="left",
                                                                                                          padx=0,
                                                                                                          pady=0)
    if info_img: # Only add if the icon exists
        info_categories = tk.Label(categories_label_frame, image=info_img, bg="#e0f7fa", cursor="question_arrow")
        info_categories.pack(side="left", padx=0, pady=0)
        create_tooltip(info_categories,
                       "Comma-separated list of scientific fields use to cluster : Computer Science, Artificial Intelligence.")

    inner_row_current += 1
    categories_text = tk.Text(one_time_processing_frame, height=4, width=50)
    categories_text.grid(row=inner_row_current, column=0, columnspan=2, pady=5, sticky="ew")

    # Populate categories if enabled
    if config["enable_data_processing"] and config["categories_scientific_cs"]:
        categories_text.insert("1.0", ", ".join(config["categories_scientific_cs"]))

    inner_row_current += 1
    filter_var = tk.BooleanVar(value=config["use_filter_data_phase"])
    filter_check = tk.Checkbutton(one_time_processing_frame,
                                  text="Enable Filtering Raw Dataset (only if raw data not already filtered)",
                                  variable=filter_var, bg="#e0f7fa" ,command=toggle_fields )
    filter_check.grid(row=inner_row_current, column=0, sticky="w", pady=2)
    if info_img: # Only add if the icon exists
        info_filter = tk.Label(one_time_processing_frame, image=info_img, bg="#e0f7fa", cursor="question_arrow")
        info_filter.grid(row=inner_row_current, column=1, sticky="w", padx=(2, 0))
        create_tooltip(info_filter, "Use this only if your input data is raw and unfiltered.")

    inner_row_current += 1
    input_frame = tk.Frame(one_time_processing_frame, bg="#e0f7fa")
    input_frame.grid(row=inner_row_current, column=0, columnspan=3, sticky="w", pady=0, padx=0)
    tk.Label(input_frame, text="Input Path to Raw Dataset:", **label_style).pack(side="left", padx=0, pady=0)
    input_path_var = tk.StringVar(value=config["input_path"])
    input_entry = tk.Entry(input_frame, textvariable=input_path_var, width=40)
    input_entry.pack(side="left", padx=(10, 0), pady=0)
    if info_img: # Only add if the icon exists
        info_input = tk.Label(input_frame, image=info_img, bg="#e0f7fa", cursor="question_arrow")
        info_input.pack(side="left", padx=2, pady=0)
        create_tooltip(info_input, "Path to the original dataset file including full name : xxxx//name.txt")

    inner_row_current += 1
    start_year_frame = tk.Frame(one_time_processing_frame, bg="#e0f7fa")
    start_year_frame.grid(row=inner_row_current, column=0, columnspan=3, sticky="w", pady=0, padx=0)
    tk.Label(start_year_frame, text="Start Year Filter:", **label_style).pack(side="left", padx=0, pady=0)
    start_year_var = tk.StringVar(value=str(config["start_year_filter"]))
    start_year_entry = tk.Entry(start_year_frame, textvariable=start_year_var, width=10)
    start_year_entry.pack(side="left", padx=(70, 0), pady=0)
    if info_img: # Only add if the icon exists
        info_start = tk.Label(start_year_frame, image=info_img, bg="#e0f7fa", cursor="question_arrow")
        info_start.pack(side="left", padx=2, pady=0)
        create_tooltip(info_start, "Minimum year to include.")

    inner_row_current += 1
    end_year_frame = tk.Frame(one_time_processing_frame, bg="#e0f7fa")
    end_year_frame.grid(row=inner_row_current, column=0, columnspan=3, sticky="w", pady=0, padx=0)
    tk.Label(end_year_frame, text="End Year Filter:", **label_style).pack(side="left", padx=0, pady=0)
    end_year_var = tk.StringVar(value=str(config["end_year_filter"]))
    end_year_entry = tk.Entry(end_year_frame, textvariable=end_year_var, width=10)
    end_year_entry.pack(side="left", padx=(75, 0), pady=0)
    if info_img: # Only add if the icon exists
        info_end = tk.Label(end_year_frame, image=info_img, bg="#e0f7fa", cursor="question_arrow")
        info_end.pack(side="left", padx=2, pady=0)
        create_tooltip(info_end, "Maximum year to include.")

    row_current += 1

    # Analysis Configuration Frame
    analysis_configuration_frame = tk.LabelFrame(left_frame, text="Analysis Configuration",
                                                 font=("Segoe UI", 12, "bold"),
                                                 fg="#1a237e", bg="#e0f7fa", bd=2, relief="groove", padx=10, pady=10)
    analysis_configuration_frame.grid(row=row_current, column=0, columnspan=3, sticky="ew", pady=(20, 0))
    analysis_configuration_frame.grid_columnconfigure(0, weight=0)
    analysis_configuration_frame.grid_columnconfigure(1, weight=0)
    analysis_configuration_frame.grid_columnconfigure(2, weight=0)

    inner_row_current = 0

    citing_percent_frame = tk.Frame(analysis_configuration_frame, bg="#e0f7fa")
    citing_percent_frame.grid(row=inner_row_current, column=0, columnspan=3, sticky="w", pady=0, padx=0)
    tk.Label(citing_percent_frame, text="Citing Percent (1-100):", **label_style).pack(side="left", padx=(0, 30),
                                                                                       pady=0)
    citing_precent_var = tk.StringVar(value=str(config["citing_precent"]))
    tk.Entry(citing_percent_frame, textvariable=citing_precent_var, width=10).pack(side="left", padx=0, pady=0)
    if info_img: # Only add if the icon exists
        info_citing = tk.Label(citing_percent_frame, image=info_img, bg="#e0f7fa", cursor="question_arrow")
        info_citing.pack(side="left", padx=(2, 0), pady=0)
        create_tooltip(info_citing, "Citing Percent (1–100):\n"
                                    "This value defines the minimum percentage of papers in Cluster A that must cite papers in Cluster B "
                                    "in order for the flow from B to A to be considered during the data processing phase.\n"
                                    "If the percentage of citing papers in A that reference B meets or exceeds this threshold, "
                                    "the flow will be processed further. Otherwise, it will be ignored.\n\n"
                                    "In other words, this is a filtering threshold that determines whether a potential citation flow between two clusters "
                                    "should be taken into account in the analysis logic.")

    inner_row_current += 1
    cited_ratio_frame = tk.Frame(analysis_configuration_frame, bg="#e0f7fa")
    cited_ratio_frame.grid(row=inner_row_current, column=0, columnspan=3, sticky="w", pady=0, padx=0)
    tk.Label(cited_ratio_frame, text="Cited Ratio (0-1):", **label_style).pack(side="left", padx=(0, 60), pady=0)
    cited_ratio_var = tk.StringVar(value=str(config["cited_ratio"]))
    tk.Entry(cited_ratio_frame, textvariable=cited_ratio_var, width=10).pack(side="left", padx=0, pady=0)
    if info_img: # Only add if the icon exists
        info_cited = tk.Label(cited_ratio_frame, image=info_img, bg="#e0f7fa", cursor="question_arrow")
        info_cited.pack(side="left", padx=(2, 0), pady=0)
        create_tooltip(info_cited, "Cited Ratio (0–1):\n"
                                   "After a flow from Cluster B to Cluster A passes the initial citing percent threshold, "
                                   "this ratio determines whether the flow is strong enough to be considered impactful.\n"
                                   "The ratio is calculated as: (number of times Cluster A cites Cluster B) divided by (total number of papers in Cluster B).\n"
                                   "If this ratio is greater than or equal to the user-defined threshold, "
                                   "the flow will be taken into account and will influence the scoring of the cited cluster.\n\n"
                                   "In short, this is a second-level filter that evaluates how significant the incoming citations are relative to the size of the cited cluster.")

    # Alluvial Diagram Generator Frame
    diagram_options_frame = tk.LabelFrame(right_frame, text="Alluvial Diagram Generator",
                                          font=("Segoe UI", 12, "bold"),
                                          fg="#1a237e", bg="#e0f7fa", bd=2, relief="groove", padx=10, pady=10)
    diagram_options_frame.pack(pady=10, fill="x", expand=True)

    # DIAGRAM OPTIONS
    for i, (path, title, var_name) in enumerate([
        (sankey_diagram_path, "Use Sankey + HTML", "use_sankey_plot"),
        (plotly_diagram_path, "Use Plotly", "use_plotly")
    ]):
        frame = tk.Frame(diagram_options_frame, bg="#e0f7fa", highlightbackground="#90a4ae", highlightthickness=1)
        frame.pack(pady=10)

        current_var = tk.BooleanVar(value=config[var_name])
        if var_name == "use_sankey_plot":
            use_r_var = current_var
        else:
            use_plotly_var = current_var

        tk.Checkbutton(frame, text=title, variable=current_var, bg="#e0f7fa").pack(anchor="w", padx=5, pady=2)

        if os.path.exists(path):
            small_img = load_resized_image(path, (400, 250))
            large_img = load_resized_image(path, (700, 800))
            lbl = tk.Label(frame, image=small_img, bg="#e0f7fa", cursor="hand2")
            lbl.image = small_img # Keep a reference!
            lbl.small = small_img
            lbl.large = large_img
            lbl.pack(pady=5)

            def enter(event, label=lbl):
                label.configure(image=label.large)

            def leave(event, label=lbl):
                label.configure(image=label.small)

            lbl.bind("<Enter>", enter)
            lbl.bind("<Leave>", leave)
        else:
            tk.Label(frame, text=f"(Preview Missing: {os.path.basename(path)})", fg="gray", bg="#e0f7fa", width=40, height=10).pack(pady=10)

    # Define normal and hover colors
    normal_bg = "#4db6ac"
    hover_bg = "#3ca59b"

    start_btn = tk.Button(
        root,
        text="Analysis and Generate Diagram",
        command=on_submit,
        bg=normal_bg,  # Default background
        fg="white",
        activebackground="#00897b",
        activeforeground="white",
        font=("Segoe UI", 11, "bold"),
        relief="ridge",
        bd=1,
        padx=20,
        pady=12,
        cursor="hand2"
    )

    # Bind hover effect
    start_btn.bind("<Enter>", lambda e: start_btn.config(bg=hover_bg))
    start_btn.bind("<Leave>", lambda e: start_btn.config(bg=normal_bg))

    start_btn.pack(pady=15, side="bottom")

    root.protocol("WM_DELETE_WINDOW", on_close)
    toggle_fields()
    root.mainloop()
    return config