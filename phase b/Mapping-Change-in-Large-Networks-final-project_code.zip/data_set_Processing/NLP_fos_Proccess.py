import json
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from collections import defaultdict

def determine_macro_categories(input_path="data_set_Processing/filtered_data.jsonl",
                               output_path="data_set_Processing/data_processed.jsonl",
                               categories=None,
                               threshold=0.3):
    """
    Classifies articles into macro categories based on FOS terms using sentence embedding similarity.

    Args:
        input_path (str): Path to the filtered dataset (default: 'filtered_data.jsonl').
        output_path (str): Path to save the processed dataset (default: 'data_processed.jsonl').
        categories (list[str], optional): List of macro categories to classify into.
                                          If None, a default scientific-CS list is used.
        threshold (float): Minimum cosine similarity to assign a category.

    Returns:
        dict: Summary containing counts per category, unclassified article count, and total processed.
    """

    if categories is None:
        categories = [
            "Computer Science",
            "Artificial Intelligence",
            "Machine Learning",
            "Data Science",
            "Mathematics",
            "Physics",
            "Computational Science",
            "Robotics"
        ]

    model = SentenceTransformer('all-MiniLM-L6-v2')
    category_embeddings = model.encode(categories)

    filtered_articles = []
    category_counts = defaultdict(int)
    unclassified_ids = []
    processed_count = 0

    with open(input_path, "r", encoding="utf-8") as f:
        for line in f:
            article = json.loads(line)
            processed_count += 1

            fos_terms = [f['name'] for f in article.get("fos", []) if f.get("w", 1) > 0]

            if not fos_terms:
                unclassified_ids.append(article["id"])
                continue

            description = ", ".join(fos_terms)
            description_embedding = model.encode([description])
            similarities = cosine_similarity(description_embedding, category_embeddings)[0]
            best_index = similarities.argmax()
            best_score = similarities[best_index]

            if best_score > threshold:
                best_category = categories[best_index]
                article["fos"] = [{"name": best_category}]
                category_counts[best_category] += 1
                filtered_articles.append(article)

                print(f"✓ Article {processed_count} → Category: {best_category} | Similarity: {best_score:.3f}")
            else:
                unclassified_ids.append(article["id"])

    with open(output_path, "w", encoding="utf-8") as f:
        for article in filtered_articles:
            f.write(json.dumps(article) + "\n")

    print("\n📊 Category Summary:")
    for category, count in sorted(category_counts.items(), key=lambda x: -x[1]):
        print(f"{category}: {count}")

    print(f"\n🗑 Articles not classified and removed: {len(unclassified_ids)}")
    print(f"\n✅ Total processed articles: {processed_count}")

    return {
        "classified_counts": dict(category_counts),
        "unclassified_count": len(unclassified_ids),
        "total": processed_count
    }
