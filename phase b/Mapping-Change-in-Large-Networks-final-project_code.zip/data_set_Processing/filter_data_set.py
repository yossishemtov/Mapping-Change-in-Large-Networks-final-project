import json
import os

def filter_data_set(input_path, start_year, end_year, output_path=None):
    """
    One-time preprocessing function that filters and cleans a raw dataset
    based on year range and FOS pr-esence, and writes the result to a JSONL file.

    Args:
        input_path (str): Path to the raw dataset (e.g., 'data.txt').
        start_year (int): Start year of the filtering range.
        end_year (int): End year of the filtering range.
        output_path (str, optional): Path to save the filtered dataset.
                                     If None, saves as 'filtered_data.jsonl' in the same directory as input.
    """
    if output_path is None:
        project_root = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(project_root, 'filtered_data.jsonl')

    # Step 1: Load and filter relevant articles
    filtered_articles = []
    processed_count = 0

    with open(input_path, 'r', encoding='utf-8') as infile:
        for line in infile:
            try:
                article = json.loads(line)
                year = article.get('year', 0)

                if start_year <= year <= end_year and article.get('fos'):
                    filtered_article = {
                        'id': article.get('id'),
                        'year': year,
                        'references': article.get('references', []),
                        'fos': article.get('fos')
                    }
                    filtered_articles.append(filtered_article)

                processed_count += 1
                if processed_count % 10000 == 0:
                    print(f"📦 Processed {processed_count} articles")

            except json.JSONDecodeError:
                continue

    print(f"🧮 Filtered {len(filtered_articles)} articles between {start_year}–{end_year} with non-empty FOS.")

    # Step 2: Collect valid article IDs
    valid_ids = set(article['id'] for article in filtered_articles)

    # Step 3: Remove references to articles not in the filtered set
    for article in filtered_articles:
        article['references'] = [
            ref_id for ref_id in article.get('references', [])
            if ref_id in valid_ids
        ]

    # Step 4: Save the filtered dataset
    with open(output_path, 'w', encoding='utf-8') as outfile:
        for article in filtered_articles:
            json.dump(article, outfile, ensure_ascii=False)
            outfile.write('\n')

    print(f"✅ Done. Saved {len(filtered_articles)} articles to {output_path}")

