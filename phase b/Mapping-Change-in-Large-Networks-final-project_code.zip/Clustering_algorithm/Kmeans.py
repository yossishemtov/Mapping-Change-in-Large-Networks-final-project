from sklearn.cluster import MiniBatchKMeans

def get_num_fos_clusters(papers, fos_to_idx):
    """
    Counts the number of unique FOS categories (that exist in fos_to_idx)
    for the given set of papers.

    Parameters:
        papers: list of paper dicts (with 'fos')
        fos_to_idx: dict mapping FOS names to indices

    Returns:
        int: number of unique FOS categories in this batch
    """
    used_fos = set()
    for paper in papers:
        for fos in paper.get("fos", []):
            if fos["name"] in fos_to_idx:
                used_fos.add(fos["name"])
                break  # assume one FOS per paper
    return len(used_fos)

def cluster_with_minibatch_kmeans(embedding_vectors, papers, fos_to_idx):
    """
    Clusters embedding vectors using MiniBatchKMeans.

    Parameters:
        embedding_vectors: numpy array of shape [N, D]
        n_clusters: int, number of clusters to create

    Returns:
        predicted_labels: list of cluster indices per vector
        (number of clusters is determined automatically from the papers)
    """
    n_clusters = get_num_fos_clusters(papers, fos_to_idx)
    kmeans = MiniBatchKMeans(n_clusters=n_clusters, random_state=42, batch_size=1024)
    predicted_labels = kmeans.fit_predict(embedding_vectors)
    return predicted_labels
