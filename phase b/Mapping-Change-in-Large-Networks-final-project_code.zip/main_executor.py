from vector_embeddings_generator.train_graphsage import train_graphsage
from Alluvial_Diagram_Generator.Alluvial_Diagram_Generator import *
from utilis.utils import *  # includes create_initial_embeddings
from Clustering_algorithm.Kmeans import cluster_with_minibatch_kmeans
from data_set_Processing.filter_data_set import *
from data_set_Processing.NLP_fos_Proccess import *
from main_UI.main_UI import run_ui
from Alluvial_Diagram_Generator.sankey_alluvial_diagram_generator import generate_single_html_sankey


import warnings
from torch_geometric.data import Data
from collections import defaultdict, Counter

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=UserWarning)


def main():
    # Load user configuration from UI
    config = run_ui()

    citing_precent = config["citing_precent"]
    cited_ratio = config["cited_ratio"]
    enable_data_processing = config["enable_data_processing"]
    use_filter_data_phase = config["use_filter_data_phase"]
    categories_scientific_cs = config["categories_scientific_cs"]
    input_path = config["input_path"]
    start_year_filter = config["start_year_filter"]
    end_year_filter = config["end_year_filter"]
    use_sankey_plot = config["use_sankey_plot"]
    use_plotly = config["use_plotly"]

    if enable_data_processing:
        if use_filter_data_phase:
            print("🔄 Starting data filtering...")
            filter_data_set(input_path, start_year_filter, end_year_filter)

        print("🧠 Starting macro category assignment...")
        determine_macro_categories(categories=categories_scientific_cs)

    print("🚀 Starting mapping changes in Large Networks pipeline...")
    jsonl_path = "data_set_Processing/data_processed.jsonl"
    print("📥 Loading papers from JSONL file...")
    papers = load_papers(jsonl_path)
    print(f"✅ Loaded {len(papers)} papers")

    print("📌 Extracting unique cluster names from FOS...")
    all_possible_clusters = set()
    for paper in papers:
        fos_list = [f["name"] for f in paper.get("fos", [])]
        if fos_list:
            cluster_name = " & ".join(sorted(fos_list))
            all_possible_clusters.add(cluster_name)
    print(f"✅ Found {len(all_possible_clusters)} unique cluster names")

    print("📎 Building paper-to-cluster mappings...")
    cluster_to_paper_ids = defaultdict(list)
    paper_id_to_cluster_name = {}
    for paper in papers:
        fos_names = sorted([f["name"] for f in paper.get("fos", [])])
        if fos_names:
            cluster_name = " & ".join(fos_names)
            cluster_to_paper_ids[cluster_name].append(paper["id"])
            paper_id_to_cluster_name[paper["id"]] = cluster_name

    print("📐 Creating initial FOS-based embeddings...")
    initial_embeddings, fos_to_idx, paper_id_to_index = create_initial_embeddings(papers, fos_dim=32)

    print("📊 Splitting embeddings by year...")
    initial_embeddings_by_year = defaultdict(list)
    for paper in papers:
        paper_id = paper["id"]
        year = paper["year"]
        if paper_id in paper_id_to_index:
            idx = paper_id_to_index[paper_id]
            initial_embeddings_by_year[year].append(initial_embeddings[idx])

    for year in initial_embeddings_by_year:
        initial_embeddings_by_year[year] = torch.stack(initial_embeddings_by_year[year])

    papers_by_year = defaultdict(list)
    for paper in papers:
        papers_by_year[paper["year"]].append(paper)

    cluster_scores = {}
    cluster_penalties = {}
    transactions_per_year = {}
    cluster_scores_per_year = {}
    cumulative_cluster_assignment = {}

    for year in sorted(papers_by_year.keys()):
        print(f"\n📅 Processing year: {year}")
        current_papers = papers_by_year[year]

        citation_graph = Data(edge_index=torch.empty((2, 0), dtype=torch.long))

        print("🧠 Training GraphSAGE model...")
        embeddings = train_graphsage(citation_graph, initial_embeddings_by_year[year], epochs=10)

        print("🔍 Extracting embedding vectors...")
        paper_ids = [p["id"] for p in current_papers]
        embedding_vectors = embeddings.numpy()

        print("📦 Clustering embeddings with MiniBatchKMeans...")
        predicted_labels = cluster_with_minibatch_kmeans(embedding_vectors, current_papers, fos_to_idx)

        cluster_fos_distribution = defaultdict(Counter)
        for idx, label in enumerate(predicted_labels):
            paper = current_papers[idx]
            for fos in paper.get("fos", []):
                cluster_fos_distribution[label][fos["name"]] += 1
                break

        print(f"📊 FOS distribution per cluster for year {year}:")
        for label, fos_counter in cluster_fos_distribution.items():
            print(f"  🔹 Cluster {label}:")
            for fos_name, count in fos_counter.most_common():
                print(f"     - {fos_name}: {count} papers")

        print("🧷 Assigning cluster labels to paper IDs...")
        label_to_paper_ids = defaultdict(list)
        for idx, pid in enumerate(paper_ids):
            label = predicted_labels[idx]
            if label != -1:
                label_to_paper_ids[label].append(pid)

        print("🏷️ Assigning human-readable cluster names (FOS)...")
        label_to_cluster_name = {}
        for label, pids in label_to_paper_ids.items():
            sample_size = max(1, int(0.2 * len(pids)))
            sample_pids = pids[:sample_size]
            fos_counter = Counter()
            for pid in sample_pids:
                cluster_name = paper_id_to_cluster_name.get(pid)
                if cluster_name:
                    fos_counter[cluster_name] += 1
            if fos_counter:
                top_fos = fos_counter.most_common(1)[0][0]
                label_to_cluster_name[label] = top_fos

        print("📌 Building final cluster assignment for this year...")
        cluster_assignment_named = {}
        for idx, pid in enumerate(paper_ids):
            label = predicted_labels[idx]
            if label in label_to_cluster_name:
                cluster_assignment_named[pid] = label_to_cluster_name[label]

        print("📈 Updating cluster scores and tracking transitions...")
        cluster_scores, cluster_penalties, transactions = update_cluster_scores(
            cumulative_cluster_assignment,
            cluster_assignment_named,
            current_papers,
            cluster_scores,
            cluster_penalties,
            year,
            citing_precent,
            cited_ratio
        )

        cumulative_cluster_assignment.update(cluster_assignment_named)
        transactions_per_year[year] = transactions
        cluster_scores_per_year[year] = dict(cluster_scores)

    print("📊 Generating alluvial flow data...")
    flow = create_alluvial_flow_from_scores_and_transactions(cluster_scores_per_year, transactions_per_year)

    if(use_sankey_plot):
        generate_single_html_sankey(flow)

    if(use_plotly):
        cluster_names = {name: name for year in cluster_scores_per_year for name in cluster_scores_per_year[year]}
        print("🎨 Plotting alluvial diagram with plotly...")
        plot_custom_alluvial(flow, cluster_names, include_clusters=[])
    print("✅ Pipeline complete.\n")


if __name__ == "__main__":
    main()
