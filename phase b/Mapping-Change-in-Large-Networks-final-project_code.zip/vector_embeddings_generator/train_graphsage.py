import torch
import torch.nn.functional as F
from torch_geometric.nn import GraphSAGE
from torch_geometric.data import Data
import torch.nn as nn

def train_graphsage(data: Data, initial_embeddings: torch.FloatTensor, epochs: int):
    """
    Applies GraphSAGE to refine the initial 32-dimensional embeddings while preserving their structure.
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    initial_x = initial_embeddings.detach().to(device)
    data = data.to(device)

    input_dim = initial_x.shape[1]  # 32
    output_dim = input_dim          # No compression, preserve original structure

    model = GraphSAGE(
        in_channels=input_dim,
        hidden_channels=64,
        num_layers=2,
        out_channels=output_dim
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        out = model(initial_x, data.edge_index)
        loss = F.mse_loss(out, initial_x)
        loss.backward()
        optimizer.step()

        if epoch % 10 == 0 or epoch == epochs - 1:
            print(f"Epoch {epoch:03d} | MSE Loss: {loss.item():.6f}")

    model.eval()
    with torch.no_grad():
        final_embeddings = model(initial_x, data.edge_index).cpu()

    return final_embeddings  # [N, 32]

