import torch
import torch.nn.functional as F
from torch_geometric.nn import GCNConv
from torch_geometric.data import Data

class FastGCN(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels):
        super(FastGCN, self).__init__()
        self.conv1 = GCNConv(in_channels, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, out_channels)

    def forward(self, x, edge_index):
        x = self.conv1(x, edge_index)
        x = F.relu(x)
        x = self.conv2(x, edge_index)
        return x

def train_fastgcn(data: Data, epochs=100, embedding_size=64):
    """
    Trains a FastGCN-like model on the citation graph.

    Parameters:
    - data: PyG Data object with x and edge_index
    - epochs: number of training epochs
    - embedding_size: output size of each node embedding

    Returns:
    - embeddings: torch.Tensor of shape [num_nodes, embedding_size]
    """
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    data = data.to(device)

    model = FastGCN(
        in_channels=data.num_node_features,
        hidden_channels=2 * embedding_size,
        out_channels=embedding_size
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=0.01)

    model.train()
    for epoch in range(epochs):
        optimizer.zero_grad()
        out = model(data.x, data.edge_index)
        loss = out.norm(dim=1).mean()  # dummy loss to shape embeddings
        loss.backward()
        optimizer.step()
        if epoch % 10 == 0:
            print(f"Epoch {epoch} | Loss: {loss.item():.4f}")

    model.eval()
    with torch.no_grad():
        embeddings = model(data.x, data.edge_index).cpu()

    return embeddings
